// EjemploHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "Cuadrado.h"
#include "conio.h"

using namespace std;

int main(void) {
   Rectangulo Rect;
   Cuadrado Cuad1;

   
   Cuad1.setWidth(6);
 
 
   Rect.setWidth(5);
   Rect.setHeight(7);
   
   cout << "Total area del cuadrado: " << Cuad1.getArea() << endl;

   // Muestra el �rea de un rectangulo
   cout << "Total area del rectangulo: " << Rect.getArea() << endl;
   getch();
   return 0;
}