#pragma once
#include "Shape.h"
class Cuadrado: public Shape {
public:
	Cuadrado(void);
	~Cuadrado(void);
	 int getArea() { 
         return (width * width); 
      }
};

