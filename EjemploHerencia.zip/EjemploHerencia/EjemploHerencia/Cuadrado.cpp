#include "StdAfx.h"
#include "Cuadrado.h"


Cuadrado::Cuadrado(void)
{
}


Cuadrado::~Cuadrado(void)
{
}
