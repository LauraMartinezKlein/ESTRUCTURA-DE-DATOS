#pragma once
// Base class
class Shape {
protected:
      int width;
      int height;   
public:
      void setWidth(int w);
      void setHeight(int h);
};

